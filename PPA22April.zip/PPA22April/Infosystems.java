package PPA;

public class Infosystems
{
    public void gun()
    {
        System.out.println("Inside gun of Infosystems");
    }
}