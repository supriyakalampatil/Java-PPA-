package PPA.LB;

public class Demo
{
    public static void sun()
    {
        System.out.println("Inside Demo sun");
    }
}